//
//  c_string.h
//  Unity-iPhone
//
//  Created by Max Botvinev on 03.10.17.
//

#ifndef c_string_h
#define c_string_h

#include <stdio.h>
const char * append(const char * a, const char * b);

#endif /* c_string_h */
